var app = angular.module( 'ngBoilerplate.body', []);

app.controller( 'bodyCtrl', function bodyCtrl( $scope ) {
});