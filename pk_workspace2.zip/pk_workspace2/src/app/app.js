angular.module('ngBoilerplate', [
    'templates-app',
    'templates-common',
    'ngBoilerplate.header',
    'ngBoilerplate.body',
    'ngBoilerplate.footer',
    'ngBoilerplate.auth',
    'ngBoilerplate.signUp',
    'ngBoilerplate.loginForm',
    'ngBoilerplate.userService',
    'ngStorage',
    'ui.router'
])

.config(function myAppConfig($stateProvider, $urlRouterProvider) {
    $stateProvider.state('app', {
        url: '/app',
        'params': { userObj: null },
        templateUrl: 'mainView.tpl.html'
    }).state('app.login', {
        url: '/login',
        controller: 'AuthCtrl',
        templateUrl: 'auth/auth.tpl.html'
    }).state('app.signup', {
        url: '/signup',
        controller: 'SignUpCtrl',
        templateUrl: 'signUp/signUp.tpl.html'
    });
    $urlRouterProvider.otherwise('/app');

})

.run(function run() {})

.controller('AppCtrl', function AppCtrl($scope, $location) {
    $scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
        if (angular.isDefined(toState.data.pageTitle)) {
            $scope.pageTitle = toState.data.pageTitle + ' | ngBoilerplate';
        }
    });
});
