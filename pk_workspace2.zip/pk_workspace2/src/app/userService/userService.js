var app = angular.module('ngBoilerplate.userService', []);
app.factory('userService', function($rootScope, $localStorage) {
    var userService = {};
    userService.storeUserInfo = [];
    userService.flag = false;
    userService.passData = function(userData) {

        userService.flag = userData.flag;
        if (!userData.islogin) {
            userService.storeUserInfo.push(userService.userInfo);
        }
            $localStorage.sesstionData = userService.storeUserInfo;

        $rootScope.$broadcast('dataPassed');
    };

    return userService;
});
