/**
 * Tests sit right alongside the file they are testing, which is more intuitive
 * and portable than separating `src` and `test` directories. Additionally, the
 * build process will exclude all `.spec.js` files from the build
 * automatically.
 */
describe('home', function() {
    beforeEach(module('ngBoilerplate.home'));
    var $scope, $rootScope;
    beforeEach(inject(function(_$rootScope_, _$controller_) {
        $rootScope = _$rootScope_;
        $scope = $rootScope.$new();
        $controller = _$controller_;
        $controller('HomeCtrl', { '$rootScope': $rootScope, '$scope': $scope });
    }));

    it('it will check the flag status of the signUp controller.', function() {
        expect($scope.flag).toEqual(true);
    });
});
