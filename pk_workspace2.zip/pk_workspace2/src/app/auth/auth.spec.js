describe('auththication example', function() {

    var authCtrl, scope;
    beforeEach(module('ngBoilerplate.auth'));


    beforeEach(inject(function($rootScope, $controller, $httpBackend) {
        authCtrl = $controller('AuthCtrl', {$scope: scope});
        scope = $rootScope.$new();
    }));
    it('says hello world!', function() {
        expect(scope.greeting).toEqual("Hello world!");
    });

});
