var app = angular.module("ngBoilerplate.auth", ['ui.bootstrap']);
app.controller('AuthCtrl', function AuthCtrl($scope, $state, $stateParams, userService, $window, $localStorage) {
    $scope.authObj = {};
    $scope.flag = true;
    $scope.greeting = 'Hello World!';
    $scope.getHandler = function() {
        if (userService.storeUserInfo != null && $localStorage.sesstionData.length > 0) {
            angular.forEach($localStorage.sesstionData, function(value, key) {
                if (value.user == $scope.authObj.user && value.pass == $scope.authObj.pass) {
                    userService.passData({ userObj: $localStorage.sesstionData[key], flag: true, islogin: true });
                }
            });
        } else {
            alert("this user not at register");
            $state.go('app.signup');
        }
    };
});
