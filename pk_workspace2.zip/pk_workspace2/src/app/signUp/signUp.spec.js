describe('SignUpCtrl', function () {

  // load the controller's module
  beforeEach(module('ngBoilerplate.signup'));
  var SignUpCtrl,scope;
  // Initialize the controller and a mock scope
  beforeEach(inject(function (_$controller_, _$rootScope_) {
    scope = _$rootScope_.$new();
    SignUpCtrl = _$controller_('SignUpCtrl', {
      $scope: scope
      // place here mocked dependencies
    });
  }));
   it('should have controller to be defined', function() {
        expect(SignUpCtrl).not.toBeNull();
    });

    it('should have scope to be defined', function() {
        expect(scope).toBeDefined();
    });

});

