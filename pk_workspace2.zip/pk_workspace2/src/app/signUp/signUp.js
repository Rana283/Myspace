var app = angular.module("ngBoilerplate.signUp", ['ui.bootstrap']);

app.controller('SignUpCtrl', function SignUpCtrl($scope, $state, $stateParams, $rootScope, userService, $window) {
    $scope.flag = false;
    $scope.authObj = {};
    $scope.getHandler = function() {
        if ($scope.authObj != null) {
            userService.passData({ userObj: $scope.authObj, flag: true, islogin: false });
        } else {
            alert("please fill the required fields");
        }
    };


});
