var app = angular.module('ngBoilerplate.header', ['ui.bootstrap']);

app.controller('headerCtrl', function headerController($scope, $state, $stateParams, $rootScope, userService, $window,$localStorage) {
    $scope.userFlag = userService.flag;
    $scope.logoutHandler = function() {
        $scope.userFlag = false;
        $state.go('app.login');
    };
    $scope.$on('dataPassed', function() {
        $state.go('app');
        $scope.userService = $localStorage.sesstionData;
        $scope.userFlag = userService.flag;
    });
});
