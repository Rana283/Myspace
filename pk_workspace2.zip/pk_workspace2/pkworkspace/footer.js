var app = angular.module( 'ngBoilerplate.footer', []);

app.controller( 'footerCtrl', function footerController( $scope ) {
});