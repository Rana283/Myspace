var app = angular.module('ngBoilerplate.header', ['ui.router']);

app.controller('headerCtrl', function headerController($scope, $state) {
});
